package com.onestep.backend.history;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

// DB 없이 Repository를 Mockito로 가짜로 만들어 Service 규칙만 검증한다.
@ExtendWith(MockitoExtension.class)
class StepHistoryServiceTest {

    private static final String DEVICE = "11111111-1111-1111-1111-111111111111";
    private static final String OTHER_DEVICE = "22222222-2222-2222-2222-222222222222";

    @Mock
    private StepHistoryRepository repository;

    private StepHistoryService service;

    @BeforeEach
    void setUp() {
        service = new StepHistoryService(repository);
    }

    private StepHistoryRequest request(Long clientRecordId, String action) {
        return new StepHistoryRequest(clientRecordId, "프로젝트", "높음", "목표", "할 일", action,
                Instant.parse("2026-11-09T07:56:25.313Z"));
    }

    // ===== save =====

    @Test
    @DisplayName("새 기록을 저장하면 created=true, 내용이 그대로 응답에 담긴다")
    void saveNew() {
        when(repository.findByDeviceIdAndClientRecordId(DEVICE, 1L)).thenReturn(Optional.empty());
        when(repository.save(any(StepHistory.class))).thenAnswer(inv -> inv.getArgument(0));

        StepHistoryService.SaveResult result = service.save(DEVICE, request(1L, "책상 정리하기"));

        assertThat(result.created()).isTrue();
        assertThat(result.history().action()).isEqualTo("책상 정리하기");
        assertThat(result.history().clientRecordId()).isEqualTo(1L);
        verify(repository).save(any(StepHistory.class));
    }

    @Test
    @DisplayName("같은 clientRecordId를 다시 보내면 새로 저장하지 않고 기존 기록을 돌려준다 (created=false)")
    void saveIsIdempotent() {
        StepHistory existing = new StepHistory(DEVICE, 1L, "프로젝트", "높음", "목표", "할 일",
                "이미 저장된 기록", Instant.parse("2026-11-09T07:56:25.313Z"));
        when(repository.findByDeviceIdAndClientRecordId(DEVICE, 1L)).thenReturn(Optional.of(existing));

        StepHistoryService.SaveResult result = service.save(DEVICE, request(1L, "다시 보낸 기록"));

        assertThat(result.created()).isFalse();
        assertThat(result.history().action()).isEqualTo("이미 저장된 기록");
        verify(repository, never()).save(any());
    }

    @Test
    @DisplayName("clientRecordId가 없으면 중복 확인 없이 항상 새로 저장한다")
    void saveWithoutClientRecordId() {
        when(repository.save(any(StepHistory.class))).thenAnswer(inv -> inv.getArgument(0));

        StepHistoryService.SaveResult result = service.save(DEVICE, request(null, "기록"));

        assertThat(result.created()).isTrue();
        verify(repository, never()).findByDeviceIdAndClientRecordId(any(), any());
    }

    @Test
    @DisplayName("action이 비어 있거나 공백이면 400")
    void saveBlankAction() {
        assertBadRequest(() -> service.save(DEVICE, request(1L, null)));
        assertBadRequest(() -> service.save(DEVICE, request(1L, "")));
        assertBadRequest(() -> service.save(DEVICE, request(1L, "   ")));
        assertBadRequest(() -> service.save(DEVICE, null));
        verify(repository, never()).save(any());
    }

    @Test
    @DisplayName("컬럼 길이를 넘으면 400 (project 1000, priority 20, goal/task/action 500)")
    void saveTooLong() {
        assertBadRequest(() -> service.save(DEVICE, new StepHistoryRequest(
                null, "가".repeat(1001), null, null, null, "행동", null)));
        assertBadRequest(() -> service.save(DEVICE, new StepHistoryRequest(
                null, null, "가".repeat(21), null, null, "행동", null)));
        assertBadRequest(() -> service.save(DEVICE, new StepHistoryRequest(
                null, null, null, "가".repeat(501), null, "행동", null)));
        assertBadRequest(() -> service.save(DEVICE, new StepHistoryRequest(
                null, null, null, null, "가".repeat(501), "행동", null)));
        assertBadRequest(() -> service.save(DEVICE, new StepHistoryRequest(
                null, null, null, null, null, "가".repeat(501), null)));
        verify(repository, never()).save(any());
    }

    @Test
    @DisplayName("딱 제한 길이까지는 저장된다")
    void saveAtLimit() {
        when(repository.save(any(StepHistory.class))).thenAnswer(inv -> inv.getArgument(0));

        StepHistoryService.SaveResult result = service.save(DEVICE, new StepHistoryRequest(
                null, "가".repeat(1000), "가".repeat(20), "가".repeat(500), "가".repeat(500),
                "가".repeat(500), null));

        assertThat(result.created()).isTrue();
    }

    @Test
    @DisplayName("빈 문자열 필드는 NULL로, action은 앞뒤 공백 제거, completedAt이 없으면 서버 시각")
    void saveNormalizesFields() {
        when(repository.save(any(StepHistory.class))).thenAnswer(inv -> inv.getArgument(0));

        service.save(DEVICE, new StepHistoryRequest(null, "", "  ", "", "", "  행동  ", null));

        ArgumentCaptor<StepHistory> captor = ArgumentCaptor.forClass(StepHistory.class);
        verify(repository).save(captor.capture());
        StepHistory saved = captor.getValue();

        assertThat(saved.getProject()).isNull();
        assertThat(saved.getPriority()).isNull();
        assertThat(saved.getGoal()).isNull();
        assertThat(saved.getTask()).isNull();
        assertThat(saved.getAction()).isEqualTo("행동");
        assertThat(saved.getCompletedAt()).isNotNull();
        assertThat(saved.getDeviceId()).isEqualTo(DEVICE);
    }

    // ===== import =====

    @Test
    @DisplayName("import: 새 기록은 저장, 빈 action·이미 있는 기록은 skipped로 센다")
    void importCountsImportedAndSkipped() {
        when(repository.findByDeviceIdAndClientRecordId(DEVICE, 1L)).thenReturn(Optional.empty());
        when(repository.findByDeviceIdAndClientRecordId(DEVICE, 2L)).thenReturn(Optional.of(
                new StepHistory(DEVICE, 2L, null, null, null, null, "이미 있음", Instant.now())));

        StepHistoryImportRequest body = new StepHistoryImportRequest(List.of(
                request(1L, "새 기록"),
                request(2L, "중복 기록"),
                request(3L, "   "),       // action이 공백 → skip
                request(4L, null)         // action이 null → skip
        ));

        StepHistoryImportResponse response = service.importRecords(DEVICE, body);

        assertThat(response.imported()).isEqualTo(1);
        assertThat(response.skipped()).isEqualTo(3);
        verify(repository, times(1)).save(any(StepHistory.class));
    }

    @Test
    @DisplayName("import: 너무 긴 예전 기록은 버리지 않고 제한 길이로 잘라서 저장한다")
    void importCutsLongFields() {
        StepHistoryImportRequest body = new StepHistoryImportRequest(List.of(
                new StepHistoryRequest(null, "가".repeat(1500), "가".repeat(50), "가".repeat(700),
                        "가".repeat(700), "가".repeat(700), null)));

        StepHistoryImportResponse response = service.importRecords(DEVICE, body);

        ArgumentCaptor<StepHistory> captor = ArgumentCaptor.forClass(StepHistory.class);
        verify(repository).save(captor.capture());
        StepHistory saved = captor.getValue();

        assertThat(response.imported()).isEqualTo(1);
        assertThat(saved.getProject()).hasSize(1000);
        assertThat(saved.getPriority()).hasSize(20);
        assertThat(saved.getGoal()).hasSize(500);
        assertThat(saved.getTask()).hasSize(500);
        assertThat(saved.getAction()).hasSize(500);
    }

    @Test
    @DisplayName("import: 요청이나 records가 null이면 0/0")
    void importNull() {
        assertThat(service.importRecords(DEVICE, null)).isEqualTo(new StepHistoryImportResponse(0, 0));
        assertThat(service.importRecords(DEVICE, new StepHistoryImportRequest(null)))
                .isEqualTo(new StepHistoryImportResponse(0, 0));
        verify(repository, never()).save(any());
    }

    // ===== list / delete =====

    @Test
    @DisplayName("목록은 이 기기의 기록만 repository 정렬 순서 그대로 응답으로 바꿔 준다")
    void list() {
        StepHistory a = new StepHistory(DEVICE, 1L, null, null, null, null, "첫째", Instant.now());
        StepHistory b = new StepHistory(DEVICE, 2L, null, null, null, null, "둘째", Instant.now());
        when(repository.findByDeviceIdOrderByCompletedAtDescIdDesc(DEVICE)).thenReturn(List.of(b, a));

        List<StepHistoryResponse> result = service.list(DEVICE);

        assertThat(result).extracting(StepHistoryResponse::action).containsExactly("둘째", "첫째");
    }

    @Test
    @DisplayName("내 기기 기록은 삭제된다")
    void deleteMine() {
        StepHistory mine = new StepHistory(DEVICE, 1L, null, null, null, null, "내 기록", Instant.now());
        when(repository.findByIdAndDeviceId(5L, DEVICE)).thenReturn(Optional.of(mine));

        service.delete(DEVICE, 5L);

        verify(repository).delete(mine);
    }

    @Test
    @DisplayName("다른 기기의 기록을 지우려 하면 없는 것처럼 404")
    void deleteOthersRecord() {
        when(repository.findByIdAndDeviceId(5L, OTHER_DEVICE)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.delete(OTHER_DEVICE, 5L))
                .isInstanceOf(ResponseStatusException.class)
                .satisfies(e -> assertThat(((ResponseStatusException) e).getStatusCode())
                        .isEqualTo(HttpStatus.NOT_FOUND));
        verify(repository, never()).delete(any());
    }

    @Test
    @DisplayName("전체 삭제는 이 기기 id로만 호출된다")
    void deleteAll() {
        service.deleteAll(DEVICE);

        verify(repository).deleteByDeviceId(DEVICE);
    }

    // ===== 도우미 =====

    private void assertBadRequest(org.assertj.core.api.ThrowableAssert.ThrowingCallable callable) {
        assertThatThrownBy(callable)
                .isInstanceOf(ResponseStatusException.class)
                .satisfies(e -> assertThat(((ResponseStatusException) e).getStatusCode())
                        .isEqualTo(HttpStatus.BAD_REQUEST));
    }
}
