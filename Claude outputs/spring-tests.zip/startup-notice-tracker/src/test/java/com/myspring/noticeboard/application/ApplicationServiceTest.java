package com.myspring.noticeboard.application;

import com.myspring.noticeboard.application.dto.ApplicationResponse;
import com.myspring.noticeboard.global.NotFoundException;
import com.myspring.noticeboard.notice.Notice;
import com.myspring.noticeboard.notice.NoticeCategory;
import com.myspring.noticeboard.notice.NoticeRepository;
import com.myspring.noticeboard.notice.OrgType;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

// DB 없이 Mockito로 Repository를 가짜로 만들어 Service 규칙만 검증
@ExtendWith(MockitoExtension.class)
class ApplicationServiceTest {

    @Mock
    private ApplicationRepository applicationRepository;

    @Mock
    private NoticeRepository noticeRepository;

    @InjectMocks
    private ApplicationService applicationService;

    private Notice notice(LocalDate deadline) {
        return Notice.builder()
                .title("테스트 공고")
                .organization("테스트 기관")
                .orgType(OrgType.PRIVATE)
                .category(NoticeCategory.MENTORING)
                .startDate(LocalDate.now().minusDays(30))
                .deadline(deadline)
                .build();
    }

    private Application applicationWithId(Long id, Notice notice) {
        Application application = new Application(notice);
        ReflectionTestUtils.setField(application, "id", id);
        ReflectionTestUtils.setField(notice, "id", 1L);
        return application;
    }

    // ===== create =====

    @Test
    @DisplayName("진행중 공고를 지원 관리에 추가하면 저장된 id를 돌려준다")
    void createSuccess() {
        Notice notice = notice(LocalDate.now().plusDays(5));
        when(noticeRepository.findByIdAndDeletedFalse(1L)).thenReturn(Optional.of(notice));
        when(applicationRepository.existsByNoticeId(1L)).thenReturn(false);
        when(applicationRepository.save(any(Application.class)))
                .thenReturn(applicationWithId(10L, notice));

        Long id = applicationService.create(1L);

        assertThat(id).isEqualTo(10L);
        verify(applicationRepository).save(any(Application.class));
    }

    @Test
    @DisplayName("없는 공고면 NotFoundException")
    void createNoticeNotFound() {
        when(noticeRepository.findByIdAndDeletedFalse(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> applicationService.create(99L))
                .isInstanceOf(NotFoundException.class)
                .hasMessageContaining("99");
        verify(applicationRepository, never()).save(any());
    }

    @Test
    @DisplayName("마감된 공고는 추가할 수 없다")
    void createClosedNotice() {
        Notice closed = notice(LocalDate.now().minusDays(1));
        when(noticeRepository.findByIdAndDeletedFalse(1L)).thenReturn(Optional.of(closed));

        assertThatThrownBy(() -> applicationService.create(1L))
                .isInstanceOf(IllegalStateException.class)
                .hasMessage("마감된 공고는 지원 관리에 추가할 수 없습니다.");
        verify(applicationRepository, never()).save(any());
    }

    @Test
    @DisplayName("이미 추가된 공고는 중복 추가할 수 없다")
    void createDuplicate() {
        Notice notice = notice(LocalDate.now().plusDays(5));
        when(noticeRepository.findByIdAndDeletedFalse(1L)).thenReturn(Optional.of(notice));
        when(applicationRepository.existsByNoticeId(1L)).thenReturn(true);

        assertThatThrownBy(() -> applicationService.create(1L))
                .isInstanceOf(IllegalStateException.class)
                .hasMessage("이미 지원 관리에 추가된 공고입니다.");
        verify(applicationRepository, never()).save(any());
    }

    // ===== 상태 변경 =====

    @Test
    @DisplayName("허용된 상태 변경은 응답에 반영된다")
    void changeStatusSuccess() {
        Application application = applicationWithId(10L, notice(LocalDate.now().plusDays(5)));
        when(applicationRepository.findById(10L)).thenReturn(Optional.of(application));

        ApplicationResponse response = applicationService.changeStatus(10L, ApplyStatus.PREPARING);

        assertThat(response.status()).isEqualTo(ApplyStatus.PREPARING);
        assertThat(response.statusLabel()).isEqualTo("준비중");
    }

    @Test
    @DisplayName("관심 상태에서 합격으로 바로 바꾸면 IllegalStateException")
    void changeStatusInvalid() {
        Application application = applicationWithId(10L, notice(LocalDate.now().plusDays(5)));
        when(applicationRepository.findById(10L)).thenReturn(Optional.of(application));

        assertThatThrownBy(() -> applicationService.changeStatus(10L, ApplyStatus.PASSED))
                .isInstanceOf(IllegalStateException.class);
    }

    @Test
    @DisplayName("없는 지원 내역이면 NotFoundException")
    void changeStatusNotFound() {
        when(applicationRepository.findById(404L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> applicationService.changeStatus(404L, ApplyStatus.PREPARING))
                .isInstanceOf(NotFoundException.class);
    }

    // ===== 메모 =====

    @Test
    @DisplayName("500자 메모는 저장되고, 501자는 IllegalArgumentException")
    void memoLengthLimit() {
        Application application = applicationWithId(10L, notice(LocalDate.now().plusDays(5)));
        when(applicationRepository.findById(10L)).thenReturn(Optional.of(application));

        ApplicationResponse ok = applicationService.updateMemo(10L, "가".repeat(500));
        assertThat(ok.memo()).hasSize(500);

        assertThatThrownBy(() -> applicationService.updateMemo(10L, "가".repeat(501)))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("메모는 500자 이하로 입력해주세요.");
    }

    // ===== 삭제 =====

    @Test
    @DisplayName("삭제하면 repository.delete가 호출된다")
    void deleteSuccess() {
        Application application = applicationWithId(10L, notice(LocalDate.now().plusDays(5)));
        when(applicationRepository.findById(10L)).thenReturn(Optional.of(application));

        applicationService.delete(10L);

        verify(applicationRepository).delete(application);
    }

    // ===== 목록/보드 =====

    @Test
    @DisplayName("보드는 상태 순서(관심→준비중→제출완료→합격→불합격)를 유지하고 상태별로 묶는다")
    void boardGroupsByStatus() {
        Application interested = applicationWithId(1L, notice(LocalDate.now().plusDays(5)));
        Application preparing = applicationWithId(2L, notice(LocalDate.now().plusDays(5)));
        preparing.changeStatus(ApplyStatus.PREPARING);
        when(applicationRepository.findAllWithNotice()).thenReturn(List.of(interested, preparing));

        Map<ApplyStatus, List<ApplicationResponse>> board = applicationService.getBoard();

        assertThat(board.keySet()).containsExactly(ApplyStatus.values());
        assertThat(board.get(ApplyStatus.INTERESTED)).hasSize(1);
        assertThat(board.get(ApplyStatus.PREPARING)).hasSize(1);
        assertThat(board.get(ApplyStatus.SUBMITTED)).isEmpty();
    }

    @Test
    @DisplayName("목록은 status로 필터링할 수 있다")
    void listFilter() {
        Application interested = applicationWithId(1L, notice(LocalDate.now().plusDays(5)));
        Application preparing = applicationWithId(2L, notice(LocalDate.now().plusDays(5)));
        preparing.changeStatus(ApplyStatus.PREPARING);
        when(applicationRepository.findAllWithNotice()).thenReturn(List.of(interested, preparing));

        assertThat(applicationService.getList(null)).hasSize(2);
        assertThat(applicationService.getList(ApplyStatus.PREPARING)).hasSize(1);
    }

    @Test
    @DisplayName("마감 3일 이내 미제출은 urgent, 마감 지난 미제출은 missed 플래그가 켜진다")
    void urgentAndMissedFlags() {
        Application urgent = applicationWithId(1L, notice(LocalDate.now().plusDays(2)));
        Application missed = applicationWithId(2L, notice(LocalDate.now().minusDays(1)));
        Application relaxed = applicationWithId(3L, notice(LocalDate.now().plusDays(20)));
        when(applicationRepository.findAllWithNotice()).thenReturn(List.of(urgent, missed, relaxed));

        List<ApplicationResponse> list = applicationService.getList(null);

        assertThat(list.get(0).urgent()).isTrue();
        assertThat(list.get(0).missed()).isFalse();
        assertThat(list.get(1).missed()).isTrue();
        assertThat(list.get(1).urgent()).isFalse();
        assertThat(list.get(2).urgent()).isFalse();
        assertThat(list.get(2).missed()).isFalse();
    }
}
