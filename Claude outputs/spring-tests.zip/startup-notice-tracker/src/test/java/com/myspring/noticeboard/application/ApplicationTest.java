package com.myspring.noticeboard.application;

import com.myspring.noticeboard.notice.Notice;
import com.myspring.noticeboard.notice.NoticeCategory;
import com.myspring.noticeboard.notice.OrgType;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class ApplicationTest {

    private Notice openNotice() {
        return Notice.builder()
                .title("테스트 공고")
                .organization("테스트 기관")
                .orgType(OrgType.PUBLIC)
                .category(NoticeCategory.COMMERCIALIZATION)
                .startDate(LocalDate.now().minusDays(1))
                .deadline(LocalDate.now().plusDays(10))
                .build();
    }

    @Test
    @DisplayName("새로 만든 지원 내역은 '관심' 상태로 시작한다")
    void startsAsInterested() {
        Application application = new Application(openNotice());

        assertThat(application.getStatus()).isEqualTo(ApplyStatus.INTERESTED);
    }

    @Test
    @DisplayName("허용된 상태 변경은 성공한다")
    void changeStatusAllowed() {
        Application application = new Application(openNotice());

        application.changeStatus(ApplyStatus.PREPARING);
        application.changeStatus(ApplyStatus.SUBMITTED);
        application.changeStatus(ApplyStatus.PASSED);

        assertThat(application.getStatus()).isEqualTo(ApplyStatus.PASSED);
    }

    @Test
    @DisplayName("허용되지 않은 상태 변경은 IllegalStateException")
    void changeStatusNotAllowed() {
        Application application = new Application(openNotice());

        assertThatThrownBy(() -> application.changeStatus(ApplyStatus.PASSED))
                .isInstanceOf(IllegalStateException.class);
        assertThat(application.getStatus()).isEqualTo(ApplyStatus.INTERESTED);
    }

    @Test
    @DisplayName("메모를 수정할 수 있다")
    void updateMemo() {
        Application application = new Application(openNotice());

        application.updateMemo("사업계획서 초안 작성");

        assertThat(application.getMemo()).isEqualTo("사업계획서 초안 작성");
    }
}
