package com.myspring.noticeboard.application;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

// 지원 상태 변경 규칙만 검증하는 순수 단위 테스트 (스프링/DB 필요 없음)
class ApplyStatusTest {

    @Test
    @DisplayName("같은 상태로 변경하는 것은 항상 허용된다")
    void sameStatusIsAllowed() {
        for (ApplyStatus status : ApplyStatus.values()) {
            assertThat(status.canChangeTo(status)).isTrue();
        }
    }

    @Test
    @DisplayName("관심/준비중에서는 합격·불합격으로 바로 갈 수 없다 (제출완료를 거쳐야 함)")
    void cannotJumpToResultBeforeSubmitted() {
        assertThat(ApplyStatus.INTERESTED.canChangeTo(ApplyStatus.PASSED)).isFalse();
        assertThat(ApplyStatus.INTERESTED.canChangeTo(ApplyStatus.FAILED)).isFalse();
        assertThat(ApplyStatus.PREPARING.canChangeTo(ApplyStatus.PASSED)).isFalse();
        assertThat(ApplyStatus.PREPARING.canChangeTo(ApplyStatus.FAILED)).isFalse();
    }

    @Test
    @DisplayName("제출완료에서는 합격·불합격으로 변경할 수 있다")
    void submittedCanGoToResult() {
        assertThat(ApplyStatus.SUBMITTED.canChangeTo(ApplyStatus.PASSED)).isTrue();
        assertThat(ApplyStatus.SUBMITTED.canChangeTo(ApplyStatus.FAILED)).isTrue();
    }

    @Test
    @DisplayName("합격/불합격에서는 제출완료로만 되돌릴 수 있다")
    void resultCanOnlyGoBackToSubmitted() {
        assertThat(ApplyStatus.PASSED.canChangeTo(ApplyStatus.SUBMITTED)).isTrue();
        assertThat(ApplyStatus.FAILED.canChangeTo(ApplyStatus.SUBMITTED)).isTrue();

        assertThat(ApplyStatus.PASSED.canChangeTo(ApplyStatus.INTERESTED)).isFalse();
        assertThat(ApplyStatus.PASSED.canChangeTo(ApplyStatus.PREPARING)).isFalse();
        assertThat(ApplyStatus.PASSED.canChangeTo(ApplyStatus.FAILED)).isFalse();
        assertThat(ApplyStatus.FAILED.canChangeTo(ApplyStatus.INTERESTED)).isFalse();
        assertThat(ApplyStatus.FAILED.canChangeTo(ApplyStatus.PASSED)).isFalse();
    }

    @Test
    @DisplayName("관심 ↔ 준비 ↔ 제출완료 사이 이동은 자유롭다")
    void freeMovementBeforeResult() {
        assertThat(ApplyStatus.INTERESTED.canChangeTo(ApplyStatus.PREPARING)).isTrue();
        assertThat(ApplyStatus.INTERESTED.canChangeTo(ApplyStatus.SUBMITTED)).isTrue();
        assertThat(ApplyStatus.PREPARING.canChangeTo(ApplyStatus.INTERESTED)).isTrue();
        assertThat(ApplyStatus.SUBMITTED.canChangeTo(ApplyStatus.PREPARING)).isTrue();
        assertThat(ApplyStatus.SUBMITTED.canChangeTo(ApplyStatus.INTERESTED)).isTrue();
    }
}
