package com.myspring.noticeboard.notice;

import com.myspring.noticeboard.global.NotFoundException;
import com.myspring.noticeboard.global.PageResponse;
import com.myspring.noticeboard.notice.dto.NoticeListResponse;
import com.myspring.noticeboard.notice.dto.NoticeRequest;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class NoticeServiceTest {

    @Mock
    private NoticeRepository noticeRepository;

    @InjectMocks
    private NoticeService noticeService;

    private NoticeRequest request(LocalDate start, LocalDate deadline) {
        return new NoticeRequest("공고 제목", "OO재단", OrgType.PRIVATE, NoticeCategory.MENTORING,
                "예비창업자", "전국", "무료", start, deadline, "https://example.com", "내용");
    }

    private Notice notice(Long id) {
        Notice notice = Notice.builder()
                .title("공고 제목").organization("OO재단")
                .orgType(OrgType.PRIVATE).category(NoticeCategory.MENTORING)
                .startDate(LocalDate.now().minusDays(3)).deadline(LocalDate.now().plusDays(7))
                .build();
        ReflectionTestUtils.setField(notice, "id", id);
        return notice;
    }

    // ===== create =====

    @Test
    @DisplayName("공고 등록 시 저장된 id를 돌려준다")
    void createSuccess() {
        when(noticeRepository.save(any(Notice.class))).thenReturn(notice(5L));

        Long id = noticeService.create(request(LocalDate.now(), LocalDate.now().plusDays(10)));

        assertThat(id).isEqualTo(5L);
    }

    @Test
    @DisplayName("접수 시작일이 마감일보다 늦으면 IllegalArgumentException")
    void createInvalidDates() {
        assertThatThrownBy(() ->
                noticeService.create(request(LocalDate.now().plusDays(5), LocalDate.now())))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("접수 시작일은 마감일보다 늦을 수 없습니다.");
        verify(noticeRepository, never()).save(any());
    }

    // ===== 상세/삭제/수정 =====

    @Test
    @DisplayName("상세 조회하면 조회수가 1 늘어난다")
    void detailIncreasesViewCount() {
        Notice notice = notice(1L);
        when(noticeRepository.findByIdAndDeletedFalse(1L)).thenReturn(Optional.of(notice));

        noticeService.getDetail(1L);

        assertThat(notice.getViewCount()).isEqualTo(1);
    }

    @Test
    @DisplayName("없는 공고 상세 조회는 NotFoundException")
    void detailNotFound() {
        when(noticeRepository.findByIdAndDeletedFalse(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> noticeService.getDetail(99L))
                .isInstanceOf(NotFoundException.class)
                .hasMessageContaining("99");
    }

    @Test
    @DisplayName("수정 화면용 조회는 조회수를 올리지 않는다")
    void editRequestDoesNotIncreaseViewCount() {
        Notice notice = notice(1L);
        when(noticeRepository.findByIdAndDeletedFalse(1L)).thenReturn(Optional.of(notice));

        NoticeRequest edit = noticeService.getEditRequest(1L);

        assertThat(edit.title()).isEqualTo("공고 제목");
        assertThat(notice.getViewCount()).isZero();
    }

    @Test
    @DisplayName("삭제는 실제 삭제가 아니라 deleted=true (소프트 삭제)")
    void softDelete() {
        Notice notice = notice(1L);
        when(noticeRepository.findByIdAndDeletedFalse(1L)).thenReturn(Optional.of(notice));

        noticeService.delete(1L);

        assertThat(notice.isDeleted()).isTrue();
        verify(noticeRepository, never()).delete(any());
    }

    @Test
    @DisplayName("수정 시 날짜가 잘못되면 IllegalArgumentException")
    void updateInvalidDates() {
        assertThatThrownBy(() ->
                noticeService.update(1L, request(LocalDate.now().plusDays(5), LocalDate.now())))
                .isInstanceOf(IllegalArgumentException.class);
    }

    // ===== 목록 =====

    private Page<Notice> pageOf(Notice... notices) {
        return new PageImpl<>(List.of(notices));
    }

    @Test
    @DisplayName("기본 목록은 진행중(OPEN) 공고만, 마감임박순(deadline asc, id desc)으로 조회한다")
    void listDefault() {
        when(noticeRepository.search(any(), any(), any(), any(), any(Pageable.class)))
                .thenReturn(pageOf(notice(1L)));

        PageResponse<NoticeListResponse> response =
                noticeService.getList(null, null, null, false, "deadline", 1, 10);

        ArgumentCaptor<Pageable> pageable = ArgumentCaptor.forClass(Pageable.class);
        verify(noticeRepository).search(eq(null), eq(null), eq(null), eq(NoticeStatus.OPEN), pageable.capture());

        assertThat(pageable.getValue().getPageNumber()).isZero();
        assertThat(pageable.getValue().getPageSize()).isEqualTo(10);
        assertThat(pageable.getValue().getSort().getOrderFor("deadline").getDirection())
                .isEqualTo(Sort.Direction.ASC);
        assertThat(pageable.getValue().getSort().getOrderFor("id").getDirection())
                .isEqualTo(Sort.Direction.DESC);
        assertThat(response.content()).hasSize(1);
        assertThat(response.page()).isEqualTo(1);
    }

    @Test
    @DisplayName("includeClosed=true면 상태 조건 없이(null) 조회한다")
    void listIncludeClosed() {
        when(noticeRepository.search(any(), any(), any(), any(), any(Pageable.class)))
                .thenReturn(pageOf());

        noticeService.getList(null, null, null, true, "deadline", 1, 10);

        verify(noticeRepository).search(eq(null), eq(null), eq(null), eq(null), any(Pageable.class));
    }

    @Test
    @DisplayName("빈 검색어는 null로, 앞뒤 공백은 제거한다")
    void listKeywordHandling() {
        when(noticeRepository.search(any(), any(), any(), any(), any(Pageable.class)))
                .thenReturn(pageOf());

        noticeService.getList("   ", null, null, false, "deadline", 1, 10);
        verify(noticeRepository).search(eq(null), any(), any(), any(), any(Pageable.class));

        noticeService.getList("  창업  ", null, null, false, "deadline", 1, 10);
        verify(noticeRepository).search(eq("창업"), any(), any(), any(), any(Pageable.class));
    }

    @Test
    @DisplayName("page는 최소 1, size는 1~50으로 보정된다")
    void listPagingClamp() {
        when(noticeRepository.search(any(), any(), any(), any(), any(Pageable.class)))
                .thenReturn(pageOf());

        noticeService.getList(null, null, null, false, "deadline", -5, 1000);

        ArgumentCaptor<Pageable> pageable = ArgumentCaptor.forClass(Pageable.class);
        verify(noticeRepository).search(any(), any(), any(), any(), pageable.capture());
        assertThat(pageable.getValue().getPageNumber()).isZero();
        assertThat(pageable.getValue().getPageSize()).isEqualTo(50);
    }

    @Test
    @DisplayName("sort=latest는 createdAt 내림차순, sort=views는 viewCount 내림차순")
    void listSortOptions() {
        when(noticeRepository.search(any(), any(), any(), any(), any(Pageable.class)))
                .thenReturn(pageOf());

        noticeService.getList(null, null, null, false, "latest", 1, 10);
        noticeService.getList(null, null, null, false, "views", 1, 10);

        ArgumentCaptor<Pageable> pageable = ArgumentCaptor.forClass(Pageable.class);
        verify(noticeRepository, org.mockito.Mockito.times(2))
                .search(any(), any(), any(), any(), pageable.capture());

        assertThat(pageable.getAllValues().get(0).getSort().getOrderFor("createdAt")).isNotNull();
        assertThat(pageable.getAllValues().get(1).getSort().getOrderFor("viewCount")).isNotNull();
    }
}
