package com.myspring.noticeboard.notice;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;

class NoticeTest {

    private Notice.NoticeBuilder baseBuilder() {
        return Notice.builder()
                .title("테스트 공고")
                .organization("테스트 기관")
                .orgType(OrgType.PUBLIC)
                .category(NoticeCategory.FUNDING)
                .startDate(LocalDate.now().minusDays(10));
    }

    @Test
    @DisplayName("마감일이 오늘이거나 미래면 OPEN")
    void openWhenDeadlineTodayOrLater() {
        assertThat(baseBuilder().deadline(LocalDate.now()).build().getStatus()).isEqualTo(NoticeStatus.OPEN);
        assertThat(baseBuilder().deadline(LocalDate.now().plusDays(3)).build().getStatus()).isEqualTo(NoticeStatus.OPEN);
    }

    @Test
    @DisplayName("마감일이 어제 이전이면 CLOSED")
    void closedWhenDeadlinePassed() {
        Notice notice = baseBuilder().deadline(LocalDate.now().minusDays(1)).build();

        assertThat(notice.getStatus()).isEqualTo(NoticeStatus.CLOSED);
    }

    @Test
    @DisplayName("새 공고의 조회수는 0, 삭제 여부는 false")
    void initialState() {
        Notice notice = baseBuilder().deadline(LocalDate.now().plusDays(1)).build();

        assertThat(notice.getViewCount()).isZero();
        assertThat(notice.isDeleted()).isFalse();
    }

    @Test
    @DisplayName("조회수 증가")
    void increaseViewCount() {
        Notice notice = baseBuilder().deadline(LocalDate.now().plusDays(1)).build();

        notice.increaseViewCount();
        notice.increaseViewCount();

        assertThat(notice.getViewCount()).isEqualTo(2);
    }

    @Test
    @DisplayName("소프트 삭제하면 deleted=true")
    void softDelete() {
        Notice notice = baseBuilder().deadline(LocalDate.now().plusDays(1)).build();

        notice.delete();

        assertThat(notice.isDeleted()).isTrue();
    }

    @Test
    @DisplayName("수정으로 마감일이 과거가 되면 상태도 CLOSED로 다시 계산된다")
    void updateRecalculatesStatus() {
        Notice notice = baseBuilder().deadline(LocalDate.now().plusDays(5)).build();

        notice.update("새 제목", "새 기관", OrgType.PRIVATE, NoticeCategory.EVENT,
                null, null, null,
                LocalDate.now().minusDays(20), LocalDate.now().minusDays(1),
                null, null);

        assertThat(notice.getTitle()).isEqualTo("새 제목");
        assertThat(notice.getStatus()).isEqualTo(NoticeStatus.CLOSED);
    }
}
